from django.apps import AppConfig


class NotifierappConfig(AppConfig):
    name = 'NotifierApp'
